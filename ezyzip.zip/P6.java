package myPack;
 public class P6{
    public void mgs(){
        System.out.println("this is myPack package method 1");
    }
     public void mg(){
        System.out.println("this is myPack package method 2");
    }
    public void mgs2(){
  System.out.println("this is myPack package method 3");
    }
    public static void main(String[] args){
        System.out.println("this is class of myPack package");
    }
}
