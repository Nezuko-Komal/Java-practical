package myPack1;
import myPack.*;
class P1{
    public static void main(String[] args){
        P6 t = new P6();
        t.mgs();
        t.mg();
    }
}
