package myPack;
 public class P6{
    public void mgs(){
        System.out.println("this is myPack package");
    }
    public static void main(String[] args){
        System.out.println("this is class of myPack package");
    }
}
