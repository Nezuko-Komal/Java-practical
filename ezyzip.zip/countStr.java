import java.util.*;
class test{
    
     public static void main(String[] args){
Scanner sc = new Scanner(System.in);
//String str1 = "";
System.out.println("enter the string");
String str = sc.nextLine();
char[] ch = str.toCharArray();
int a = ch.length;
System.out.println(a);
    }
}